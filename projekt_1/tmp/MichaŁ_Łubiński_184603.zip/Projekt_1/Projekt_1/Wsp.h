#pragma once

class Wsp {
public:
	int x = 0;
	int y = 0;
	Wsp(int x, int y);
};