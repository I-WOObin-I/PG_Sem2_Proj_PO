#pragma once
#include "Wsp.h"

Wsp::Wsp(int x, int y) : x(x), y(y) {}